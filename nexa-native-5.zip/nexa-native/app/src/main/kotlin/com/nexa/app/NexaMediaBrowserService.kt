package com.nexa.app

import android.service.media.MediaBrowserService
import android.os.Bundle
import android.media.browse.MediaBrowser.MediaItem

/**
 * Car/IoT integration goes through Android Auto's sanctioned MediaBrowserService
 * + media session APIs — there is no public API for a third-party app to push
 * raw commands to a specific head unit (e.g. a Skoda's native infotainment).
 * What IS achievable: Nexa registers as a media source Android Auto can browse
 * and control (play/pause/skip/voice search), same mechanism Spotify/YouTube
 * Music use. True infotainment-level control (climate, native nav) is
 * manufacturer-gated and not available to third-party apps at all.
 */
class NexaMediaBrowserService : MediaBrowserService() {

    override fun onGetRoot(clientPackageName: String, clientUid: Int, rootHints: Bundle?): BrowserRoot {
        return BrowserRoot("nexa_root", null)
    }

    override fun onLoadChildren(parentId: String, result: Result<List<MediaItem>>) {
        // Populate with playable items from your media source of choice
        // (local library, streaming API) — wired to MediaSessionCompat
        // playback controls that Android Auto surfaces on the car screen.
        result.sendResult(mutableListOf())
    }
}
