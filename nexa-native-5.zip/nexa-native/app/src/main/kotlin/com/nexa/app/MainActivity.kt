package com.nexa.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tts: NexaTts
    private val backend = NexaBackendClient(baseUrl = "http://10.0.2.2:8000") // point at your backend host

    private val messageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val sender = intent.getStringExtra(NexaNotificationListenerService.EXTRA_SENDER) ?: return
            val text = intent.getStringExtra(NexaNotificationListenerService.EXTRA_TEXT) ?: return

            // Long message -> summarize before speaking; short one -> speak as-is.
            Thread {
                val toSpeak = if (text.length > 160) backend.summarize(sender, text) else text
                tts.speak("Message from $sender: $toSpeak")
            }.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = NexaTts(this)

        ContextCompat.registerReceiver(
            this, messageReceiver,
            IntentFilter(NexaNotificationListenerService.ACTION_MESSAGE_RECEIVED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        layout.addView(Button(this).apply {
            text = "Enable Accessibility Service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        layout.addView(Button(this).apply {
            text = "Enable Notification Access (message reading)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })

        setContentView(layout)
    }

    override fun onDestroy() {
        unregisterReceiver(messageReceiver)
        tts.shutdown()
        super.onDestroy()
    }
}
