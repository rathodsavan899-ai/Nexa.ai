package com.nexa.app

import android.content.Context
import android.speech.tts.TextToSpeech
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import org.json.JSONObject

/** Thin TTS wrapper so any component can speak without owning engine lifecycle. */
class NexaTts(context: Context) : TextToSpeech.OnInitListener {
    private var engine: TextToSpeech = TextToSpeech(context, this)
    private var ready = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            engine.language = Locale.getDefault()
            ready = true
        }
    }

    fun speak(text: String) {
        if (!ready) return
        engine.speak(text, TextToSpeech.QUEUE_ADD, null, null)
    }

    fun shutdown() = engine.shutdown()
}

/**
 * Talks to the same Python backend (FastAPI) used by the Flutter build —
 * see backend/app/main.py's /summarize and /reply/draft endpoints. Point
 * baseUrl at your phone's backend host (e.g. a LAN address, or 10.0.2.2 for
 * an emulator reaching a host machine).
 */
class NexaBackendClient(private val baseUrl: String) {

    fun summarize(sender: String, text: String): String {
        val body = JSONObject().put("sender", sender).put("text", text)
        val response = post("/summarize", body) ?: return text.take(140)
        return response.optString("summary", text.take(140))
    }

    fun draftReply(sender: String, originalText: String, instruction: String): String {
        val body = JSONObject()
            .put("sender", sender)
            .put("original_text", originalText)
            .put("instruction", instruction)
        val response = post("/reply/draft", body) ?: return instruction
        return response.optString("draft", instruction)
    }

    private fun post(path: String, body: JSONObject): JSONObject? {
        return try {
            val conn = URL("$baseUrl$path").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.connectTimeout = 5000
            conn.readTimeout = 8000
            OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
            val responseText = conn.inputStream.bufferedReader().use { it.readText() }
            JSONObject(responseText)
        } catch (e: Exception) {
            null
        }
    }
}
