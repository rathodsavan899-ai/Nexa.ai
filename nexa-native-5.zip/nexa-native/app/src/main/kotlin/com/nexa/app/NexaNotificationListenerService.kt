package com.nexa.app

import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Reads incoming notifications from message apps and announces them via TTS,
 * and can send a "smart reply" back through the SAME quick-reply action the
 * app itself exposes (RemoteInput) — this is the same mechanism Android Auto
 * and Wear OS use, not a hack. Two real limits:
 *   1. The user must manually grant this in Settings > Notification access —
 *      exactly like the Accessibility Service, Android will not let an app
 *      self-enable this.
 *   2. Auto-sending only works for notifications that expose a RemoteInput
 *      "Reply" action (WhatsApp, SMS, and Gmail all normally do). Apps that
 *      don't expose one cannot be replied to this way — there is no
 *      general-purpose API for that.
 */
class NexaNotificationListenerService : NotificationListenerService() {

    private val monitoredPackages = setOf(
        "com.whatsapp",
        "com.google.android.gm",          // Gmail
        "com.google.android.apps.messaging" // Android Messages (SMS)
    )

    // Keyed by notification key so a later smart-reply call knows which
    // conversation's RemoteInput action to fire.
    private val pendingReplyActions = mutableMapOf<String, PendingReply>()

    private data class PendingReply(
        val action: android.app.Notification.Action,
        val remoteInputs: Array<RemoteInput>
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in monitoredPackages) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString() ?: "Unknown sender"
        val text = extras.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString() ?: ""
        if (text.isBlank()) return

        // Cache the reply action (if the notification has one) for later use.
        sbn.notification.actions?.forEach { action ->
            val inputs = RemoteInput.getRemoteInputs(action.actionIntent)
            if (inputs != null && inputs.isNotEmpty() && action.title?.contains("Reply", ignoreCase = true) == true) {
                pendingReplyActions[sbn.key] = PendingReply(action, inputs)
            }
        }

        // Hand off to the app process for summarization + TTS announcement.
        // Kept as a broadcast so MainActivity/a foreground service owns the
        // TTS engine lifecycle rather than this listener (listeners should
        // stay lightweight).
        sendBroadcast(Intent(ACTION_MESSAGE_RECEIVED).apply {
            putExtra(EXTRA_SENDER, title)
            putExtra(EXTRA_TEXT, text)
            putExtra(EXTRA_KEY, sbn.key)
            setPackage(packageName)
        })
    }

    /** Call this once the user has dictated a reply and it's ready to send. */
    fun sendSmartReply(notificationKey: String, replyText: String): Boolean {
        val pending = pendingReplyActions[notificationKey] ?: return false
        val remoteInput = pending.remoteInputs.first()
        val intent = Intent()
        val bundle = Bundle()
        bundle.putCharSequence(remoteInput.resultKey, replyText)
        RemoteInput.addResultsToIntent(pending.remoteInputs, intent, bundle)
        return try {
            pending.action.actionIntent.send(this, 0, intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        pendingReplyActions.remove(sbn.key)
    }

    companion object {
        const val ACTION_MESSAGE_RECEIVED = "com.nexa.app.MESSAGE_RECEIVED"
        const val EXTRA_SENDER = "sender"
        const val EXTRA_TEXT = "text"
        const val EXTRA_KEY = "notification_key"
    }
}
